# Configurer les trois offres Stripe — CyberDirecteur

Les identifiants que tu as transmis sont des **produits** (`prod_...`), pas des **tarifs** (`price_...`). Le serveur connaît les produits suivants et refuse de payer un tarif rattaché à un autre produit :

- Mensuel : `prod_VUiq9YfDbrgA2f` — tarif récurrent **mensuel**.
- Annuel : `prod_VUicouxQJ4T45V` — tarif **ponctuel**, accès 12 mois.
- Permanent : `prod_VUitLfHuBTmPmr` — tarif **ponctuel**, sans fin d'accès prévue tant que le service existe.

## Étapes

1. Demande à ton parent ou responsable légal de gérer le compte marchand Stripe.
2. Dans Stripe > Catalogue de produits, ouvre chaque produit et ajoute ou retrouve le tarif correspondant.
3. Copie le **Price ID** qui commence par `price_` et renseigne les variables `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_ANNUAL`, `STRIPE_PRICE_LIFETIME` (voir `.env.example`).
4. Renseigne `STRIPE_SECRET_KEY` uniquement sur l'hébergement serveur, `SITE_URL` avec une adresse HTTPS publique, et un `SESSION_SECRET` aléatoire d'au moins 32 caractères.
5. Sur un hébergement Node.js : `npm install`, puis `npm start`. Tester d'abord avec les clés de test Stripe et les produits/tarifs du même environnement test.
6. Ouvre le site via son URL HTTPS et fais un paiement en mode test. Vérifie les trois formules, l'accès aux cours, au quiz et la désactivation des emplacements publicitaires.

**Sécurité et limites :** le paiement s'effectue via Stripe Checkout et le serveur vérifie la session Stripe. Il n'y a cependant **pas encore de comptes clients et de récupération des achats** : le navigateur initial conserve l'accès via cookie. Avant une commercialisation, ajouter une authentification sécurisée, une base de données, un webhook Stripe vérifié, la restauration de l'accès client, des documents légaux et des tests de bout en bout. Ne jamais publier `premium.json`, `.env` ou `server.js` avec un hébergement statique qui rend tous les fichiers téléchargeables. Ne pas afficher de faux badges de certification ni promettre une sécurité absolue.

Sources : https://docs.stripe.com/api/checkout/sessions · https://stripe.com/payments/checkout
