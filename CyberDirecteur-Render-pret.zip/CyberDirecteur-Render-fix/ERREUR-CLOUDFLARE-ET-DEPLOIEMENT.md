# Pourquoi l'erreur Cloudflare apparaît

L'erreur `Could not detect a directory containing static files (e.g. html, css and js) for the project` signifie que Wrangler ne trouve pas le dossier d'assets statiques qu'il doit publier.

Ce projet contient aussi `server.js` (Express) et protège les cours dans `premium.json`. Il doit être lancé comme un **service Node.js**, pas publié tel quel comme simple site statique. Publier tout le dossier comme assets publics risquerait d'exposer `premium.json`.

## Déploiement conseillé : Render Web Service

Les fichiers de ce ZIP sont directement à la racine du projet (il n'y a pas de sous-dossier `CyberDirecteur`).

1. Décompresser le ZIP.
2. Envoyer tous les fichiers du dossier dans un dépôt GitHub, à la racine du dépôt.
3. Dans Render, choisir **New → Web Service**, connecter ce dépôt, puis les paramètres suivants :
   - Runtime: Node
   - Root Directory: laisser vide
   - Build Command: `npm install`
   - Start Command: `npm start`
4. Renseigner les variables d'environnement demandées par Render :
   - `STRIPE_SECRET_KEY`: commencer avec la clé de test `sk_test_...`
   - `STRIPE_PRICE_MONTHLY`: ID `price_...` du tarif 5 EUR, récurrent chaque mois
   - `STRIPE_PRICE_ANNUAL`: ID `price_...` du tarif ponctuel de 25 EUR
   - `STRIPE_PRICE_LIFETIME`: ID `price_...` du tarif ponctuel de 40 EUR
   - `SITE_URL`: URL HTTPS exacte donnée par Render, sans slash final
   - `SESSION_SECRET`: secret aléatoire d'au moins 32 caractères (Render peut générer une valeur)
5. Après le premier déploiement, copier l'URL Render dans `SITE_URL` et redéployer si nécessaire.
6. Tester les trois achats en mode test avant de passer en mode réel. Les clés et Price IDs doivent appartenir au même mode Stripe.

Les identifiants `prod_...` identifient les produits. Le serveur attend les identifiants de prix `price_...` correspondants.

## Important

- Ne publiez jamais `premium.json` comme asset statique ni la clé Stripe dans `index.html` ou `script.js`.
- Le site ne peut pas exécuter `server.js` avec un simple hébergement Cloudflare Pages statique. Pour rester sur Cloudflare, le backend devrait être réécrit pour Workers/Pages Functions et les contenus privés conservés côté serveur.
- La configuration Render est préparée, mais aucun compte/clé/paiement n'a été testé depuis cet environnement.
