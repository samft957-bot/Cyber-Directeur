# CyberDirecteur — Configuration des 3 formules Stripe

## Pour un parent ou responsable légal
Stripe exige des conditions d’âge et un représentant légal pour les comptes de mineurs. L’adulte responsable doit réaliser la configuration du compte marchand, des paiements et des obligations légales.

## Produits / Prix
Dans Stripe > Catalogue de produits, définir trois tarifs (ou trois produits) :

1. **Mensuel** — tarif récurrent, tous les mois → copier `price_...` vers `STRIPE_PRICE_MONTHLY`.
2. **Annuel (12 mois, sans renouvellement)** — tarif **ponctuel** → copier vers `STRIPE_PRICE_ANNUAL`.
3. **Permanent (paiement unique)** — tarif **ponctuel** → copier vers `STRIPE_PRICE_LIFETIME`.

Ne pas utiliser un tarif `récurrent annuel` pour l’offre annuelle ponctuelle. Le prix s’affiche dans Stripe avant l’achat ; personnaliser les libellés affichés sur le site si vous souhaitez afficher les montants dès la page Tarifs.

## Serveur
- Installer Node.js sur hébergement compatible et HTTPS (Render, etc.).
- Dans les variables d’environnement du serveur, renseigner les six entrées du fichier `.env.example`.
- `npm install` puis `npm start`.
- Le serveur n’envoie au navigateur que `index.html`, `style.css`, `script.js`; ne jamais publier `premium.json` ni `.env` sur un hébergement statique.
- En mode Stripe test, utiliser les clés et identifiants des prix test.
- Tester achat mensuel, annuel, permanent ; accès refusé avant achat ; accès Premium après achat ; expiration annuelle et annulation mensuelle.

## Limites à résoudre avant lancement commercial
- L’accès est identifié par **cookie signé dans le navigateur de l’achat**. Ajouter une connexion utilisateur, récupération d’accès multi-appareils, une base de données et webhooks Stripe signés avant toute mise en vente publique.
- Les achats ponctuels sont vérifiés auprès de Stripe, pas dans `localStorage`. Pour l’annuel, le serveur calcule 12 mois calendaires à partir du paiement validé.
- Le plan « permanent » promet un accès sans échéance programmée **tant que le service est exploité**, et non une durée éternelle ; définir clairement les conditions de vente.
- Tester remboursements, litiges et révocations : la validation actuelle ne gère pas tous ces événements. Vérifier fiscalité et protection des données avec un adulte/professionnel.
