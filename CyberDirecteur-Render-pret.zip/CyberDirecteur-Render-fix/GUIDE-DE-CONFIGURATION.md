# CyberDirecteur — guide Stripe (Belgique)

## 1. Comprendre les fichiers

`index.html`, `style.css` et `script.js` : site public, 12 cours de base et menus. `premium.json` : les **6 cours Premium et 72 questions**, protégé côté serveur par une liste blanche de fichiers accessibles. `server.js` : serveur Node.js qui vérifie le statut auprès de Stripe. Les clés secrètes ne doivent jamais être mises dans le HTML ou GitHub.

**Important :** ouvrir `index.html` directement sur Chromebook affiche le site gratuit et les cadenas, mais ne permet ni paiement ni accès Premium. Pour les abonnements, le site doit être hébergé sur un serveur Node.js HTTPS (par exemple un service Node sur Render). Cloudflare Pages statique seule ne suffit pas pour exécuter ce serveur Express.

## 2. Compte Stripe et responsabilité

Comme tu as 15 ans, configure ce compte **avec un parent ou responsable légal**, en respectant l'âge et les justificatifs exigés par Stripe et les règles belges applicables à l'activité. N'invente jamais une date de naissance ou une identité. Vérifiez ensemble les obligations commerciales, fiscales, les informations légales et les conditions d'abonnement.

## 3. Paramétrer Stripe en MODE TEST d'abord

1. Depuis le **[tableau de bord Stripe](https://dashboard.stripe.com/)**, activer le mode test.
2. Aller à **Catalogue des produits / Product catalog** → **Ajouter un produit**.
3. Nommer le produit « CyberDirecteur Premium » ; ajouter un tarif **récurrent mensuel en EUR** (choisi avec ton parent). Pour éviter toute ambiguïté, pas d'essai gratuit automatique tant que tu ne l'as pas décidé.
4. Copier **l'identifiant du prix** (commence par `price_`), pas le numéro du produit (`prod_`).
5. Dans **Développeurs → Clés API**, récupérer la **clé secrète de test** (`sk_test_...`). Ne jamais la partager par chat, ni l'inscrire dans les fichiers publics.
6. Dans **Paramètres → Facturation → Portail client**, activer la modification de moyens de paiement et la résiliation, puis enregistrer.

## 4. Déployer sur un hébergement Node.js

1. Envoyer ce projet sur un dépôt privé ou sur un service d'hébergement acceptant Node.js (sans y placer de clé secrète).
2. Commande de construction : `npm install` (ou `npm ci` après avoir généré un lockfile).
3. Commande de démarrage : `npm start`.
4. Dans le tableau de bord de l'hébergeur, ajouter les variables d'environnement ci-dessous.

| Variable | Exemple (ne pas copier les valeurs fictives) |
|---|---|
| `SITE_URL` | `https://ton-site.example` — l'adresse exacte en HTTPS, sans `/` final |
| `STRIPE_SECRET_KEY` | `sk_test_...` |
| `STRIPE_PRICE_ID` | `price_...` |
| `SESSION_SECRET` | chaîne aléatoire et secrète d'au moins 32 caractères (idéalement 64) |

Le serveur utilise `PORT` fourni par l'hébergeur. **Ne mets pas de variables secrètes dans Cloudflare Pages static assets ou dans `script.js`.**

## 5. Test complet

1. Sur l'URL du site publié : vérifier que les cours gratuits s'ouvrent.
2. Aller vers « Quiz » : le cadenas doit s'afficher. Essayer aussi d'ouvrir un cours Premium : cadenas.
3. Un appel non connecté à `/api/premium/questions` ou `/api/premium/course/0` doit répondre **403** et ne pas révéler le contenu.
4. Depuis « Abonnement », cliquer « S'abonner avec Stripe » en mode test, suivre le paiement test fourni par Stripe.
5. Après redirection automatique vers le site **dans le même navigateur**, les cours Premium et le quiz doivent s'ouvrir.
6. Utiliser « Gérer mon abonnement » pour tester la résiliation : le statut est revalidé auprès de Stripe à chaque requête. L'accès reste actif jusqu'à la fin de la période déjà payée si l'abonnement est simplement programmé pour s'arrêter à échéance.
7. Tester un autre navigateur non connecté : l'accès doit rester fermé.

**Limite de cette version :** elle associe l'accès au navigateur qui a effectué le paiement grâce à un cookie sécurisé, sans système de connexion par email. Après effacement des cookies ou changement d'appareil, il faut une fonctionnalité de récupération de compte (authentification sécurisée + base de données) à ajouter avant de proposer une expérience commerciale complète. Ne démarre pas de ventes réelles tant que ce point n'est pas résolu.

## 6. Passer aux paiements réels

Après les essais et la mise en conformité : faire valider le compte Stripe par ton responsable légal, passer au mode réel, remplacer la clé `sk_test_...` par `sk_live_...` **et** l'identifiant `price_` par celui du mode réel. Afficher prix, périodicité, renouvellement, droit de résiliation, CGV, mentions légales, politique de confidentialité et informations relatives à l'âge. Ne pas confondre test réussi et prêt à commercialiser.

## 7. Google AdSense et publicités halal

Le site contient uniquement des *espaces réservés*. Les annonces ne sont pas diffusées par ce projet tant que tu n'as pas configuré AdSense, le consentement RGPD et les vrais blocs d'annonces. Dans AdSense, utilise **Contrôles de blocage / Blocking controls** pour désactiver autant que possible les catégories sensibles (alcool, jeux d'argent, rencontres, produits financiers à intérêt, etc.). Il n'existe **aucune garantie absolue** de conformité halal. Le contenu publicitaire devra être soumis aux règles Google et à une solution de consentement adaptée à l'UE. Pour les abonnés Premium, n'initialise pas d'annonce et ne charge pas de script publicitaire.

## 8. Documentation officielle

- [Stripe Checkout subscriptions](https://docs.stripe.com/billing/subscriptions/build-subscriptions)
- [Stripe Customer Portal](https://docs.stripe.com/customer-management)
- [Stripe clés API](https://docs.stripe.com/keys)
- [Stripe conditions](https://stripe.com/legal/ssa)

## Structure simplifiée
Tous les fichiers sont désormais dans **un seul dossier**. Le serveur ne sert que `/`, `/index.html`, `/style.css`, `/script.js` et ses endpoints `/api`. Les fichiers `premium.json`, `server.js`, `.env.example` ne sont pas téléchargeables depuis le site. **Ne déploie pas ce dossier complet avec un hébergeur statique**, qui ignorerait ces protections.
