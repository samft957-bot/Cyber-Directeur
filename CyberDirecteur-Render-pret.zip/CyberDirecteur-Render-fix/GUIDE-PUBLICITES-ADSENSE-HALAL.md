# CyberDirecteur — Emplacements Google AdSense

## Emplacements prêts

Quatre emplacements sont prévus dans le site :

- `home` : après la bannière d’accueil ;
- `courses` : après les cartes de cours sur l’accueil ;
- `lesson` : en bas d’un cours gratuit ;
- `offers` : en bas de la page des formules.

Les emplacements sont volontairement masqués lorsqu’un abonnement Premium est confirmé par le serveur. Les visiteurs gratuits voient un bloc clairement étiqueté « PUBLICITÉ » ; des annonces réelles ne s’affichent qu’après configuration.

## Identifiant éditeur fourni

`ca-pub-6733605147043912`

Le site charge le script AdSense de façon différée depuis `script.js` — avec l’URL officielle ci-dessous — seulement si AdSense est activé, qu’une unité est configurée et que le signal de consentement attendu est disponible :

```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6733605147043912" crossorigin="anonymous"></script>
```

Le script n’est pas ajouté statiquement dans `index.html`, afin de ne pas le charger avant le contrôle de consentement prévu.

## Activer les annonces correctement

1. Faire approuver le site et le compte AdSense. L’approbation n’est pas garantie.
2. Dans AdSense, créer des unités d’annonces display et copier leurs identifiants numériques `data-ad-slot`.
3. Dans `script.js`, renseigner les quatre valeurs vides de `ADSENSE.slots` : `home`, `courses`, `lesson`, `offers`.
4. Installer une CMP certifiée par Google et conforme aux règles de consentement applicables dans l’EEE. Relier le véritable signal de la CMP à `ADSENSE.consentReady`. Ne pas simplement forcer cette valeur à `true`.
5. Après l’approbation, la configuration des unités et du consentement, passer `ADSENSE.enabled` à `true`.
6. Tester sur l’URL publique en HTTPS. Les annonces ne s’affichent pas en ouvrant `index.html` avec `file://`.

Les variables sont volontairement désactivées par défaut (`enabled: false`, `consentReady: false`, identifiants de slots vides), pour éviter une activation prématurée.

## Publicités selon tes critères halal

AdSense ne propose pas d’interrupteur « halal » et aucun filtre ne garantit que 100 % des annonces correspondent à ces critères. Dans AdSense, ouvrir **Brand safety / Paramètres de blocage** et bloquer les catégories disponibles qui ne conviennent pas, notamment alcool, jeux d’argent/casinos, rencontres, sexualité et contenus suggestifs ainsi que les services financiers fondés sur les intérêts lorsque la catégorie existe. Utiliser aussi le Centre de vérification des annonces pour bloquer les annonces non souhaitées et réexaminer régulièrement les réglages.

Ne promets pas une conformité halal absolue : le filtrage limite les risques, mais ne les élimine pas totalement.

## Sécurité et confidentialité

- Les blocs publicitaires sont distincts des boutons d’achat et du contenu de cours.
- Les annonces ne sont pas placées sur les pages de cours Premium.
- Le script de publicités ne peut pas se substituer à une CMP ni à une politique de confidentialité.
- Ne publie pas `premium.json`, `.env` ou `server.js` en tant que fichiers statiques accessibles publiquement.
- Vérifie les exigences AdSense, de consentement et de protection des données avant la mise en ligne.

## Liens utiles

- https://support.google.com/adsense/answer/164131?hl=fr
- https://support.google.com/adsense/answer/186376?hl=fr
- https://support.google.com/adsense/answer/9183243?hl=fr
