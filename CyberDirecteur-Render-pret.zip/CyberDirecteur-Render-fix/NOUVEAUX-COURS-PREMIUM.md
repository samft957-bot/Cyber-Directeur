# CyberDirecteur Académie — Nouveaux cours Premium

6 modules approfondis, 48 leçons et 48 activités avec corrigés détaillés, rédigés en français pour débutants.

## Installation
Conserve le dossier `private` côté serveur. Lance `npm install`, configure les variables dans `.env` sur ton hébergeur, puis `npm start`. Le contenu est délivré par `/api/premium/course/:id` uniquement après vérification de l’abonnement. N’envoie pas `private/premium.json` dans le dossier public.

## Sources consultées et principes pédagogiques
- NIST CSF 2.0 (version française) : https://www.nist.gov/publications/nist-cybersecurity-framework-csf-20-french-translation
- OWASP Top 10 : https://owasp.org/projects/top-ten
- Python tutorial officiel en français : https://docs.python.org/fr/3/tutorial/
- Microsoft Zero Trust : https://learn.microsoft.com/en-us/security/zero-trust/microsoft-365-zero-trust
- ANSSI : https://cyber.gouv.fr/

Les contenus sont des explications originales, non des reproductions de sources. Les exercices restent défensifs ou sur papier. Les six modules ne remplacent pas une formation professionnelle certifiante.

## Paiement
Ce ZIP ne configure pas automatiquement ton compte Stripe et ne simule pas des abonnements payants. Suis `GUIDE-DE-CONFIGURATION.md`.
