# Tarifs CyberDirecteur — configuration Stripe

| Offre | Prix affiché | Configuration Stripe |
|---|---|---|
| Mensuel | 5 € / mois | Tarif récurrent de 5,00 EUR tous les mois |
| Annuel | 25 € / 12 mois | Tarif ponctuel de 25,00 EUR, accès valable 12 mois |
| Permanent | 40 € une seule fois | Tarif ponctuel de 40,00 EUR, accès sans date d’expiration prévue tant que le service existe |

Dans Stripe, ouvre chaque produit et relève **l’identifiant de tarif `price_...`**, différent de l’identifiant produit `prod_...`. Renseigne dans l’hébergement : `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_ANNUAL`, `STRIPE_PRICE_LIFETIME`.

Le serveur compare le produit, le type de tarif, la devise EUR et le montant à ceux annoncés sur le site. Si un tarif n’est pas correctement configuré, le paiement sera refusé plutôt que de présenter un montant différent. Teste chaque formule en mode test Stripe avant publication.

Les clés Stripe secrètes doivent rester dans les variables d’environnement du serveur. Un adulte responsable doit superviser les comptes marchands et les obligations légales.
