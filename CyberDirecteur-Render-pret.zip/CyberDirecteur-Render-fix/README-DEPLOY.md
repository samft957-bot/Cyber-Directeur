# CyberDirecteur

Application Node.js + Express avec fichier `index.html`, `style.css`, `script.js`, API Stripe et données Premium non exposées par les routes publiques du serveur.

## Développement local

1. Installer Node.js.
2. Exécuter `npm install`.
3. Configurer les variables d'environnement décrites dans `.env.example`.
4. Exécuter `npm start`.

Sur Chromebook sans Node.js local, déployer depuis GitHub vers un hébergement Node.js, par exemple Render.

Voir `ERREUR-CLOUDFLARE-ET-DEPLOIEMENT.md`.
