# CyberDirecteur — abonnements Premium sécurisés

- **12 cours gratuits** accessibles à tous.
- **6 cours Premium + 72 questions** dans premium.json, non servi par le serveur.
- **Vérification Stripe côté serveur**, sans confiance dans `localStorage`.
- **Tous les fichiers dans un seul dossier, HTML, CSS et JS séparés**, design conservé.

Lancement : `npm install` puis `npm start`, après configuration de `SITE_URL`, `STRIPE_SECRET_KEY`, `STRIPE_PRICE_ID`, `SESSION_SECRET` dans les variables d'environnement de l'hébergeur.

Lire **GUIDE-DE-CONFIGURATION.md** avant tout paiement réel.

**Structure :** tous les fichiers sont à la racine, sans sous-dossiers. `premium.json` est privé grâce à une liste blanche de routes publiques dans `server.js`. Ne publie PAS ce dossier sur un hébergement purement statique : cela exposerait les leçons payantes.
